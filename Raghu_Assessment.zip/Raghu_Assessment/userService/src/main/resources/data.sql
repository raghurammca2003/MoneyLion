INSERT INTO 
	TBL_FEATURE (email_id, feature_name, enable) 
VALUES
  	('rr@sample.com', 'email', 1),
  	('rag@sample.com', 'outlook', 0),
  	('sim@sample.com', 'printer', 1),
  	('zzz@sample.com', 'vending', 1),
  	('ss@may.com', 'caravan', 0);