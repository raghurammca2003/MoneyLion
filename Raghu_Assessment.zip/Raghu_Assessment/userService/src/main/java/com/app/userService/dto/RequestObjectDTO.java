package com.app.userService.dto;

import java.io.Serializable;

import lombok.Data;
import lombok.ToString;

@Data
@ToString
public class RequestObjectDTO <T> implements Serializable{
	private static final long serialVersionUID = 3954289042568286284L;
	private T data;
}
