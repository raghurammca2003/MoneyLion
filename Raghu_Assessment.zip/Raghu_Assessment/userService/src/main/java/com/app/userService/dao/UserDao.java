package com.app.userService.dao;

import java.io.IOException;
import java.sql.SQLException;
import java.util.Map;

import org.json.JSONObject;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import com.app.userService.dto.ReturnObjectDTO;
import com.app.userService.entity.FeatureEntity;
import com.app.userService.exception.RecordNotFoundException;
import com.app.userService.pojo.FeatureRequestDtls;

public interface UserDao {
	
	public Map fetchFeatureDetails(String email, String featureName) throws SQLException, IOException, ClassNotFoundException, RecordNotFoundException;
	public HttpStatus createOrUpdateFeatureDetails(FeatureRequestDtls featureRequestDtls) throws SQLException, IOException, ClassNotFoundException, RecordNotFoundException;
	
}
