package com.app.userService.pojo;

import lombok.Data;

@Data
public class FeatureRequestDtls {
	
	public String email;
	public String featureName;
	public Boolean enable;
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getFeatureName() {
		return featureName;
	}
	public void setFeatureName(String featureName) {
		this.featureName = featureName;
	}
	public Boolean getEnable() {
		return enable;
	}
	public void setEnable(Boolean enable) {
		this.enable = enable;
	}

}
