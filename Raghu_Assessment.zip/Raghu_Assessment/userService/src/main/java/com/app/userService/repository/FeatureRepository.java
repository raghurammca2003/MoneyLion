package com.app.userService.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.app.userService.entity.FeatureEntity;
 

public interface FeatureRepository
        extends JpaRepository<FeatureEntity, Long> {

	Optional<FeatureEntity> findByEmailAndFeatureName(String email, String featureName);
	Optional<FeatureEntity> findByEmailAndFeatureNameAndEnable(String email, String featureName, long enable);
 
}
