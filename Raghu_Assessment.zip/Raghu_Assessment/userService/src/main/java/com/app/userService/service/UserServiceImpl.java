package com.app.userService.service;

import java.io.IOException;
import java.sql.SQLException;
import java.util.Map;

import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Isolation;
import org.springframework.transaction.annotation.Transactional;

import com.app.userService.dao.UserDao;
import com.app.userService.dto.ReturnObjectDTO;
import com.app.userService.entity.FeatureEntity;
import com.app.userService.exception.RecordNotFoundException;
import com.app.userService.pojo.FeatureRequestDtls;

@Service("UserService")
public class UserServiceImpl implements UserService{
	
	@Autowired
	UserDao userDao;
	
	public Map fetchFeatureDetails (String email, String featureName) throws ClassNotFoundException, SQLException, IOException, RecordNotFoundException {
		return userDao.fetchFeatureDetails(email, featureName);
	}

	@Override
	public HttpStatus createOrUpdateFeatureDetails(FeatureRequestDtls featureRequestDtls)
			throws SQLException, IOException, ClassNotFoundException, RecordNotFoundException {
		// TODO Auto-generated method stub
		return userDao.createOrUpdateFeatureDetails(featureRequestDtls);
	}

}
