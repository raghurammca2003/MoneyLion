package com.app.userService.dto;

import java.io.Serializable;

import lombok.Data;
import lombok.ToString;

@Data
@ToString
public class ReturnObjectDTO <T> implements Serializable{
	private static final long serialVersionUID = 3843621918093059219L;

	private boolean status;
	private String message;
	private T data;
	
	public ReturnObjectDTO() {
		super();
	}
	
	public ReturnObjectDTO(boolean status, String message, T data) {
		super();
		this.status=status;
		this.message=message;
		this.data=data;
	}
}
