package com.app.userService.dao;

import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Isolation;
import org.springframework.transaction.annotation.Transactional;

import com.app.userService.entity.FeatureEntity;
import com.app.userService.exception.RecordNotFoundException;
import com.app.userService.pojo.FeatureRequestDtls;
import com.app.userService.repository.FeatureRepository;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Component
public class UserDaoImpl implements UserDao{
	
	@Autowired
	FeatureRepository featureRepository;
	
    public Map fetchFeatureDetails(String email, String featureName) throws SQLException, RecordNotFoundException
    {
		log.info("Inside DaoImpl Email:::"+email+"  featureName:::"+featureName);
        Optional<FeatureEntity> employee = featureRepository.findByEmailAndFeatureNameAndEnable(email,featureName,1);
        log.info("Is Present"+employee.isPresent());
        HashMap map = new HashMap();
        map.put("canAccess", employee.isPresent());
        return map;
    }
	
	@Transactional
    public HttpStatus createOrUpdateFeatureDetails(FeatureRequestDtls featureRequestDtls) throws RecordNotFoundException
    {
		String strEmail=featureRequestDtls.getEmail();
		String strFeatureName=featureRequestDtls.getFeatureName();
		log.info("strEmail:::"+strEmail);
		log.info("strFeatureName:::"+strFeatureName);
        Optional<FeatureEntity> employee = featureRepository.findByEmailAndFeatureName(strEmail,strFeatureName);
         
        if(employee.isPresent())
        {
        	FeatureEntity newEntity = employee.get();
            log.info("featureRequestDtls.getEnable():::"+featureRequestDtls.getEnable());
            if(featureRequestDtls.getEnable())
            {
            	newEntity.setEnable((long) 1);
            }else {
            	newEntity.setEnable((long) 0);
            }
            featureRepository.saveAndFlush(newEntity);
            return HttpStatus.OK;
        } else {
            return HttpStatus.NOT_MODIFIED;
        }
    }

}
