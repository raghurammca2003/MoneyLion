package com.app.userService.controller;

import java.io.IOException;
import java.sql.SQLException;
import java.util.Map;

import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.app.userService.dto.ReturnObjectDTO;
import com.app.userService.exception.RecordNotFoundException;
import com.app.userService.pojo.FeatureRequestDtls;
import com.app.userService.service.UserService;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@RestController
@RequestMapping("/userService")
public class UserController {

	@Autowired
	UserService userService;
	
	@RequestMapping(value="/feature", method = RequestMethod.GET, produces = {"application/json"})
	public Map fetchUserFeatures(@RequestParam String email, @RequestParam String featureName) throws ClassNotFoundException, SQLException, IOException, RecordNotFoundException {
		log.info("emailId:::"+email);
		log.info("featureName:::"+featureName);
		Map responseObj=userService.fetchFeatureDetails(email, featureName);
		log.info("responseObj:::"+responseObj);
		return responseObj;
	}
	
	@RequestMapping(value="/feature", method = RequestMethod.POST, produces = {"application/json"})
	public HttpStatus createOrUpdateFeatureDetails(@RequestBody FeatureRequestDtls featureRequestDtls) throws ClassNotFoundException, SQLException, IOException, RecordNotFoundException {
		return userService.createOrUpdateFeatureDetails(featureRequestDtls);
	}
}
